!function ($) {
  $.ender({
    qr: require('qr')
  })
}(ender)